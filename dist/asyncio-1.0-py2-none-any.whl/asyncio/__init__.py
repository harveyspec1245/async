from .countasync import capital_case
